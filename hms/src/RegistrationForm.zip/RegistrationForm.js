import React, { useState } from 'react';
import { Link } from "react-router-dom";
import './RegistrationForm.css';
import axios from 'axios';

function RegistrationForm() {
  const [formData, setFormData] = useState({
    name: '',
    emailid: '',
    mobileno: '',
    gender: '',
    address: '',
    username: '',
    password: '',
    confirmpassword: '',
  });

  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const validateForm = () => {
    const newErrors = {};

    if (!formData.name || !formData.name.trim()) {
      newErrors.name = 'Name is required';
    }

    if (!formData.emailid || !formData.emailid.trim()) {
      newErrors.emailid = 'Email is required';
    } else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(formData.emailid)) {
      newErrors.emailid = 'Invalid email address';
    }

    if (!formData.mobileno || !formData.mobileno.trim()) {
      newErrors.mobileno = 'Mobile Number is required';
    } else if (!/^\d{10}$/.test(formData.mobileno)) {
      newErrors.mobileno = 'Invalid mobile number';
    }

    if (!formData.gender || !formData.gender.trim()) {
      newErrors.gender = 'Gender is required';
    }

    if (!formData.address || !formData.address.trim()) {
      newErrors.address = 'Address is required';
    }

    if (!formData.username || !formData.username.trim()) {
      newErrors.username = 'Username is required';
    }

    if (!formData.password || !formData.password.trim()) {
      newErrors.password = 'Password is required';
    } else if (formData.password.length < 6) {
      newErrors.password = 'Password must be at least 6 characters long';
    }

    if (formData.password !== formData.confirmpassword) {
      newErrors.confirmpassword = 'Passwords do not match';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (validateForm()) {
      try {
        // Make a POST request to the backend endpoint
        const response = await axios.post('http://localhost:8080/hotelmanagement/save', formData);
        if (response.data.success) {
          // Show a success message using alert or a custom popup
          alert('Registration successful! Your account has been created.');
        } else {
          // Show an unsuccessful registration message
          alert('Registration successful! Your account has been created.');
        }
      } catch (error) {
        console.error('Error during registration:', error);
        if (error.response) {
          console.error('Server responded with:', error.response.data);
        }
        // Show a general error message
        alert('Registration failed. Please try again later.');
      }
    }
  };    
  return (
    <>
   
    <div className="container">
       
    
</div>

    <div className="registration-container" style={{marginTop:"2.5cm", height:"16cm", boxShadow:"100%",alignContent:"center",marginLeft:"14cm"}}>
      <h1 style={{marginTop:"-1cm"}}><b>Registration</b></h1><br/>
      <form onSubmit={handleSubmit}>

        <div className="form-group">
          <label>Name{"\t"}{"\t"}: </label>{"\t"}
          <input type="text" name="name" style={{marginLeft:"1cm"}} value={formData.name} onChange={handleChange} />
          <span className="error-message">{errors.name}</span>
        </div><br/>
        <div className="form-group">
          <label>EmailId{"\t"}{"\t"}: </label>{"\t"}
          <input type="text" name="emailid" style={{marginLeft:"0.75cm"}} value={formData.emailid} onChange={handleChange} />
          <span className="error-message">{errors.emailid}</span>
        </div><br/>
         <div className="form-group">
          <label>Mobile No{"\t"}{"\t"}: </label>{"\t"}
          <input type="text" style={{marginLeft:"0.2cm"}} name="mobileno" value={formData.mobileno} onChange={handleChange} />
          <span className="error-message">{errors.mobileno}</span>
        </div><br/>

{/*        
        <div className="form-group">
          <label>Email OTP:</label>
          <input type="text" name="emailOtp" value={formData.emailOtp} onChange={handleChange} />
        </div> */}
         <div className="form-group">
            <label>Gender{"\t"}{"\t"}: </label>{"\t"}
            <select name="gender" style={{marginLeft:"0.75cm"}} value={formData.gender} onChange={handleChange} >
              <option>--select--</option>
              <option>Male</option>
              <option>Female</option>
            </select>
              <span className="error-message">{errors.gender}</span>
            </div><br/> 
        <div className="form-group">
          <label>Address{"\t"}{"\t"}: </label>{"\t"}
          <textarea name="address" style={{marginLeft:"0.6cm"}} value={formData.address} onChange={handleChange} />
          <span className="error-message">{errors.address}</span>
        </div><br/>

        <div className="form-group">
          <label>Username{"\t"}: {"\t"}</label>{"\t"}
          <input type="text" style={{marginLeft:"0.2cm"}} name="username" value={formData.username} onChange={handleChange} />
          <span className="error-message">{errors.username}</span>
        </div><br/>

        <div className="form-group">
          <label>Password{"\t"}: {"\t"}</label>{"\t"}
          <input type="password"  style={{marginLeft:"0.35cm"}} name="password" value={formData.password} onChange={handleChange} />
          <span className="error-message">{errors.password}</span>
        </div><br/>

        <div className="form-group">
          <label>Confirm Password{"\t"}{"\t"}: </label>{"\t"}<br/>
          <input type="password"  style={{marginLeft:"2.7cm"}} name="confirmpassword" value={formData.confirmpassword} onChange={handleChange} />
          <span className="error-message">{errors.confirmpassword}</span>
        </div><br/><br/>
        <Link to={'/LoginCard'}>
        <button type="submit" style={{marginLeft:"2.2cm",width:"4cm",height:"0.8cm"}}>Register</button>
        </Link>
      </form>
     </div>

   

 </>
  );
}

export default RegistrationForm;