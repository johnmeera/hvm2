import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';  // Import useNavigate for React Router v6
import axios from 'axios';
import './LoginCard.css';

function LoginCard() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  // Use useNavigate for React Router v6
  const navigate = useNavigate();

  const handleUsernameChange = (e) => {
    setUsername(e.target.value);
  };

  const handlePasswordChange = (e) => {
    setPassword(e.target.value);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await axios.post('http://localhost:8080/hotelmanagement/login', {
        username,
        password,
      });

      // Assuming your backend returns a success flag in response.data
      if (response.data.success) {
        // Redirect to another page upon successful login
        navigate('/LandingPage'); // Replace with the desired route
      } else {
        console.log('Login failed:', response.data.message);
        // Add your logic for handling unsuccessful login
      }
    } catch (error) {
      console.error('Login failed:', error.message);
      // Add your logic for handling login errors
    }
  };

  return (
   
      <div className="login-box" style={{backgroundColor:'black' }}>
        <h2>Login Page</h2>
        
        <form onSubmit={handleSubmit}>
          <div className="user-box">
            <input
              type="text"
              placeholder="Username"
              name="username"
              value={username}
              onChange={handleUsernameChange}
              required
            />
            <label>Username</label>
          </div>
          <div className="user-box">
            <input
              type="password"
              placeholder="Password"
              name="password"
              value={password}
              onChange={handlePasswordChange}
              required
            />
            <label>Password</label>
          </div>
          <Link to={"/Admindashboard"} >
          <button type="submit" style={{width:'80px',height:'30px',marginLeft:'36%',backgroundColor:'whitesmoke',borderRadius:'8px',color:"black"}}>ADMIN</button>
          </Link>
          <Link to={"/Customerdashboard"} >
          <button type="submit" style={{width:'80px',height:'30px',marginLeft:'36%',backgroundColor:'whitesmoke',borderRadius:'8px',color:"black"}}>Customer</button>
          </Link>
          <Link to={"/Restaurantdashboard"} >
          <button type="submit" style={{width:'80px',height:'30px',marginLeft:'36%',backgroundColor:'whitesmoke',borderRadius:'8px',color:"black"}}>Restaurant</button>
          </Link>
        </form>

      </div>
   
  );
}

export default LoginCard;
