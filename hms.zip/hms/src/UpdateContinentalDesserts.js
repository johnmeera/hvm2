import React, { useState } from "react";
import axios from 'axios';
import { Link } from "react-router-dom";
import './UpdateContinentalBreakfast.css';

function UpdateContinentalDesserts() {
    const [item, setItem] = useState({
        breakfast: '',
        curries: '',
        desserts: '',
        drinks: '',
        maincourse: '',
        soups: '',
        starters: ''
    });

    const handleChange = (e) => {
        const { name, value } = e.target;
        setItem({ ...item, [name]: value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        console.log('item :', item);
        try {
            const response = await axios.put('http://localhost:8081/continental/save', item);
            console.log('Item updated successfully:', response.data);
        } catch (error) {
            console.error('Error updating item:', error);
        }
    };

    return (
        <>
            <center>
                <div className="update">
                    <div className="updateitems-container">
                        <div className="updateitems-options">
                           
                        <h3>Update items</h3>
                        <div className="su" type="Desserts">
                                <label><b>Desserts :</b></label>
                                <input type='text' name='desserts' list='Desserts' value={item.desserts} onChange={handleChange} placeholder='Add new item'  /><br/><br></br>
                                <datalist id="Desserts">
                                    <option value="Strawberry Cake">Strawberry Cake</option>
                                    <option value="ButterScotch Ice Cream">ButterScotch Ice Cream</option>
                                    <option value="Gulab Jabunm">Gulab Jabunm</option>
                                    <option value="Kaju Katli">Kaju Katli</option>
                                    <option value="Kheer">Kheer</option>
                                </datalist>
                            </div>
                            <div className="su" type="D_price">
                                <label><b>D_price :</b></label>
                                <input type='text' name='d_price' list="D_price" value={item.d_price} onChange={handleChange} placeholder='Add new item' /><br/><br></br>
                            </div>
                           
                           
                        </div> 
                    </div>
                    <button className='s' type='submit' onClick={handleSubmit}>Update</button><br/>
                    <Link to={'/ContinentalMenu'}>
                        <button className='s' type='submit' >Back</button>
                    </Link>
                </div>
            </center>
        </>
    )
}

export default UpdateContinentalDesserts;
