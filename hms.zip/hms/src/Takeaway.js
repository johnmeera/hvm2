import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './Takeaway.css';
import { jsPDF } from 'jspdf';
import html2canvas from 'html2canvas';

function TakeawayComponent() {
  const [takeaway, setTakeaway] = useState(null);

  const getTakeawayById = async (id) => {
    try {
      const response = await axios.get(`http://localhost:8081/api-v1/get/${id}`);
      setTakeaway(response.data);
    } catch (error) {
      console.error('Error fetching takeaway by ID:', error);
    }
  };

  useEffect(() => {
    getTakeawayById(2); // Fetching data with ID 2
  }, []);

  const getCurrentDateTime = () => {
    const currentDate = new Date();
    return currentDate.toLocaleString();
  };


  const printPdf = () => {
    const input = document.getElementById('takeaway-details');

    html2canvas(input).then((canvas) => {
      const imgData = canvas.toDataURL('image/jpg');
      const pdf = new jsPDF('p', 'mm', 'a1');
      const width = pdf.internal.pageSize.getWidth();
      const height = pdf.internal.pageSize.getHeight();
      const scaleFactor = 0;
      pdf.addImage(imgData, 'JPG', 0, 0, width*scaleFactor, height*scaleFactor);
      pdf.save('takeaway-details.pdf');
    });
  };

  return (
    <>
    <div className="bill-container" id="takeaway-details">
      <div className="bill-heading">
       {/* <h1 className="bill-heading">Takeaway Details</h1> */}

        <img src="https://www.bestfreewebresources.com/wp-content/uploads/2012/02/hotel-logo-12.png" alt="HMS" className="logo" />
          <div className='time'>
      <p>{getCurrentDateTime()}</p>
    </div>
      </div>
      
         <h3 className='heading'>Hotel Taj</h3>
        <div className='left1'>2-4-234/45, </div>
        <div className='left2'>Swaroop Nagar, Uppal,</div>
        <div className='left'>Medchal-Malkajgiri-500039</div>
      
        <div className="additional">
        {takeaway && (
          <>
            <p style={{marginLeft:"25cm",marginTop:"-2cm"}}><strong>Customer name:</strong> {takeaway.customername}</p>
            <p style={{marginLeft:"25cm"}}><strong>Mobile number:</strong> {takeaway.mobilenumber}</p>
            <p style={{marginLeft:"25cm"}}><strong>Id:</strong> {takeaway.id}</p>
          </>
        )}
      </div>
      <table className="takeaway-table">
        <thead>
          <tr>
            <th>Type</th>
            <th>Payment Type</th>
            <th>Items</th>
            <th>Unit</th>
            <th>Price</th>
            <th>Total</th>
          </tr>
        </thead>
        <tbody>
          {takeaway && (
            <tr>
              <td>{takeaway.type}</td>
              <td>{takeaway.paymenttype}</td>
              <td>{takeaway.items}</td>
              <td>{takeaway.unit}</td>
              <td>{takeaway.price}</td>
              <td>{takeaway.total}</td>
              </tr>
           
          )}
        </tbody>
      </table>
      <div className="additional-details">
        {takeaway && (
          <>
            <p style={{marginLeft:"25cm"}}><strong>Delivery Charge:</strong> {takeaway.deliverycharge}</p>
            <p style={{marginLeft:"25cm"}}><strong>GST:</strong> {takeaway.gst}</p>
            <p style={{marginLeft:"25cm"}}><strong>Net Total:</strong> {takeaway.nettotal}</p>
          </>
        )}
      </div>
    </div>
    <div className="bill-buttons">
    <button type="button" onClick={printPdf} className="print-button">Print</button>
  </div>
  </>
  );
}

export default TakeawayComponent;






