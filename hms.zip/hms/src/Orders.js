import React from 'react';
import { Link } from "react-router-dom";
import './Orders.css';

const Orders = () => {
  return (
    <div className="containerad">
      
      <div className="search-container">
        <input type='search' placeholder='Search...' className='search-input'  style={{width:"20cm"}}/>
      </div><br/>
      <div className='offers'>
  <h4 style={{marginTop:"2cm",marginLeft:"-5cm"}}>Best offers</h4>
</div> 
      <div className="sidebar">
        <ul>
        <Link to={"/Allorders"} style={{textDecoration:"none"}}>
          <li><a href="#" style={{marginLeft:"-0.2cm"}}>Orders</a></li>
          </Link>
          <Link to={'/Repostat'}>
          <li><a href="#" style={{marginLeft:"-0.3cm"}}>Reports</a></li>
          </Link>
          <Link to={'/Restaurantmenu'}>
          <li><a href="#" style={{marginLeft:"-0.7cm"}}>MenuItems</a></li>
          </Link>
          <Link to={'/LoginCard'}>
          <li><a href='/LoginCard' style={{marginLeft:"-0.4cm"}}>Signout</a></li>
          </Link>
        </ul>
      </div>
     
  <div className='cardado1'>
  <div className='image-container'>
    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcReYekkoR4Y508aYt-28Q4enmppjPCqGnSCOA&usqp=CAU" alt="Croissant" className='c1'/>
    <div><h6 style={{marginTop:"0.5cm"}}><b>Today Croissant starting at Rs.149 only</b></h6></div>
       <div> Actual price Rs.240</div>
    
  </div>
  </div>
  <div className='cardado2'>
  <div className='image-container'>
    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSTbnh5a6QOXaIR6FTPQ_XkvuwmZbwvTmuiqQ&usqp=CAU" alt="Omelette" className='c2'/>
    <div><h6 style={{marginTop:"0.5cm"}}><b>Today Omelette starting at Rs.70 only</b></h6></div>
       <div> Actual price Rs.90</div>
  </div>
  </div>
  <div className='cardado3'>
   <div className='image-container'>
    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSNge5-dgiqPGd1d2K6a4LkRpg1ECUIUyCOzg&usqp=CAU" alt="Caesar Salad" className='c3'/>
    <div><h6 style={{marginTop:"0.5cm"}}> <b>Today Caesar Salad starting at Rs.90 only</b></h6></div>
    <div> Actual price Rs.140</div>
  </div>
  </div>
  {/* <div className='image-container'>
    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTbBMNaH849NqBsKgvm3WOc5ZoZjpSB3_fXUQ&usqp=CAU" alt="Quiche Lorraine" className='c4'/>
    <h4>Quiche Lorraine</h4>
  </div>   */}


      
    </div>
  );
};

export default Orders;

