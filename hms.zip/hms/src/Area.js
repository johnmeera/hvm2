import "./Area.css";
import { Link } from "react-router-dom";

function Area(){
return(
<>
<div className="container" style={{ backgroundColor: "lightgray", width: "30cm", minHeight: "100vh", minWidth: "196vh" }}>
      <div className="header1">
                    <img src="https://us.123rf.com/450wm/yupiramos/yupiramos1408/yupiramos140801125/30843448-hotel-design-over-gray-background-vector-illustration.jpg?ver=6" alt="loading.." style={{ marginTop: "0.3cm", marginLeft: "1.3cm", width: "4cm", height: "3cm" }}></img><br />
                    <h2 style={{ float: "inline-start", marginLeft: "1cm" }}><b>Hotel Name</b></h2>
                    <h4 style={{ float: "inline-end", marginTop: "-1cm", marginRight: "1cm", marginBottom: "0" }}><b>Nikhil Tammineedi</b></h4><br /><br />
                    <h5 style={{ float: "inline-end", opacity: "0.5", marginTop: "-1cm", marginRight: "1cm" }}><b>id:2484</b></h5>
                </div>
                <div className="navbar30" style={{ display: "flex", justifyContent: "center", backgroundColor: "black", height: "2cm", transition: "background-color 0.3s", marginTop: "-2.35cm", width: "39.4cm" }}>
                   <ul style={{ listStyleType: "none", margin: 0, padding: 0, display: "flex" }}>
                    <li style={{ marginLeft: "6cm", marginTop: "0.5cm", fontSize: "larger" }}>
                        <a href="#info" style={{ color: "whitesmoke", textDecoration: "none", transition: "color 0.3s" }}>Info</a>
                    </li>
                    <li style={{ marginLeft: "0cm", marginTop: "0.5cm", fontSize: "larger" }}>
                        <a href="#rooms" style={{ color: "whitesmoke", textDecoration: "none", transition: "color 0.3s" }}>Rooms</a>
                    </li>
                    <li style={{ marginLeft: "0cm", marginTop: "0.5cm", fontSize: "larger" }}>
                        <a href="#food" style={{ color: "whitesmoke", textDecoration: "none", transition: "color 0.3s" }}>Food</a>
                    </li>
                    <li style={{ marginLeft: "0cm", marginTop: "0.5cm", fontSize: "larger" }}>
                        <a href="/Addcust" style={{ color: "whitesmoke", textDecoration: "none", transition: "color 0.3s" }}>Addon's</a>
                    </li>
                    <li style={{ marginLeft: "0cm", marginTop: "0.5cm", fontSize: "larger" }}>
                        <a href="#areainfo" style={{ color: "whitesmoke", textDecoration: "none", transition: "color 0.3s" }}>Areainfo</a>
                    </li>
                    <li style={{ marginLeft: "0cm", marginTop: "0.5cm", fontSize: "larger" }}>
                        <a href="/Mybookings" style={{ color: "whitesmoke", textDecoration: "none", transition: "color 0.3s" }}>My Bookings</a>
                    </li>
                    <li style={{ marginLeft: "2cm", marginTop: "0.5cm", fontSize: "larger", transition: "background-color 0.3s" }}>
                        <a href="#signout" style={{ color: "whitesmoke", textDecoration: "none" }}>Sign-Out</a>
                    </li>
                </ul>
            </div>
            <h3 className="customerabac"style={{marginTop:"0cm",marginLeft:"5.5cm"}}>Date&time :</h3>
<br/>
<h3 className="customersabac"style={{marginTop:"0cm",marginLeft:"5.5cm"}}>Customer ID :</h3>

 <div class="containerarea" style={{padding:"70px",marginTop:"4cm",marginLeft:"2cm"}}>
    <div class="cardarea">
      <img src="https://images.unsplash.com/photo-1562644296-23b1879b73e5?q=80&w=1000&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8bmFuZGklMjBoaWxscyUyQyUyMGluZGlhfGVufDB8fDB8fHww" alt="Card Image 1"></img>
      <div class="cardarea-content">
        <div class="cardarea-title">Nandhi Hills</div>
        <div class="cardarea-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</div>
      </div>
    </div>

    <div class="cardarea">
      <img src="https://i.pinimg.com/originals/0f/44/34/0f44347c1961308b75c7aef63affe5a0.jpg" alt="Card Image 2"></img>
      <div class="cardarea-content">
        <div class="cardarea-title">Chikkaballapur Isha Foundation</div>
        <div class="cardarea-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</div>
      </div>
    </div>

    <div class="cardarea">
      <img src="https://upload.wikimedia.org/wikipedia/commons/5/52/Hogenakkal_Falls_Close.jpg" alt="Card Image 3"></img>
      <div class="cardarea-content">
        <div class="cardarea-title">Hogenakkal Falls</div>
        <div class="cardarea-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</div>
      </div>
    </div>

    {/* <div class="card">
      <img src="https://im.indiatimes.in/content/2023/Nov/stone-chariot-hampi-tourism-entry-fee-timings-holidays-reviews-header_654dddba5fdf9.jpg?w=1200&h=900&cc=1" alt="Card Image 4"></img>
      <div class="card-content">
        <div class="card-title">Hampi</div>
        <div class="card-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</div>
      </div>
    </div> */}
<div class="cardarea">
      <img src="https://live.staticflickr.com/2831/33041439210_11bbf6bb21_b.jpg" alt="Card Image 6"></img>
      <div class="cardarea-content">
        <div class="cardarea-title">Mysore Palace</div>
        <div class="cardarea-description">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</div>
      </div>
    </div>
    
  </div>
  <Link to={'/Customerdashboard'}>
                <button type="submit" className="btn btn-light" style={{marginTop:"10cm",marginLeft:"2cm",backgroundColor:"black",color:"whitesmoke"}}><b>Back</b></button>
                </Link>
  </div>
  <div className="footercontent" style={{backgroundColor:"black",width:"40.4cm",marginLeft:"-0.3cm",height:"6cm",marginTop:"auto"}}><br/>
                <footer class="footer" id="contact">     
                <div class="footer__col">
                     <h4 style={{color:"whitesmoke",marginLeft:"12cm"}}>OUR SERVICES</h4>
                    <ul class="footer__links">
                        <li style={{marginLeft:"10.5cm",marginTop:"-0.5cm"}}><a href="#" style={{color:"whitesmoke",textDecoration:"none"}}>Concierge Assistance</a></li>
                        <li style={{marginLeft:"10.3cm"}}><a href="#" style={{color:"whitesmoke",textDecoration:"none"}}>Flexible Booking Options</a></li>
                        <li style={{marginLeft:"11cm"}}><a href="#" style={{color:"whitesmoke",textDecoration:"none"}}>Airport Transfers</a></li>
                        <li style={{marginLeft:"10.5cm"}}><a href="#" style={{color:"whitesmoke",textDecoration:"none"}}>Wellness & Recreation</a></li>
                    </ul>
                    </div>
                    <br></br>
                    <div class="footer__col">
                    <h4 style={{marginLeft:"24cm",color:"whitesmoke",marginTop:"-5.3cm"}}>CONTACT US</h4>
                    
                        <li style={{marginLeft:"21cm",marginTop:"1cm"}}><a href="#" style={{color:"whitesmoke",textDecoration:"none"}} >anarghyacommunications@gmail.com</a></li>
                        <li style={{marginLeft:"22.6cm"}}><a href="#" style={{color:"whitesmoke",textDecoration:"none"}}>Call now : 9845612340</a></li>
                    
                    </div>
     
      
                </footer>
                </div>
                <div className="footercontent2" style={{backgroundColor:"whitesmoke",width:"40.55cm",marginLeft:"-0.5cm"}}>
                <div class="footer__bar" >
                © 2023-2024 Anarghya Communications. All Rights Reserved.
                </div>
                </div>
</>
);
}
export default Area;