import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import './ChineaseMenu.css';

const ChineaseMenu = () => {
  const [breakfastItems, setBreakfastItems] = useState([]);
  const [curriesItems, setCurriesItems] = useState([]);
  const [soupsItems, setSoupsItems] = useState([]); 
  const [startersItems, setStartersItems] = useState([]); 
  const [mainCourseItems, setMainCourseItems] = useState([]); 
  const [dessertsItems, setDessertsItems] = useState([]); 
  const [drinksItems, setDrinksItems] = useState([]); 
  const [cart, setCart] = useState([]);
  
  const addToCart = (itemName, itemPrice) => {
    // Your addToCart logic
  };
  
  const removeFromCart = (itemName) => {
    // Your removeFromCart logic
  };
  
  const decrementQuantity = (itemName) => {
    // Your decrementQuantity logic
  };
  
  useEffect(() => {
    fetchBreakfastItems();
    fetchCurriesItems();
    fetchSoupsItems();
    fetchStartersItems(); 
    fetchMainCourseItems(); 
    fetchDessertsItems(); 
    fetchDrinksItems(); 
  }, []);
  

  const fetchBreakfastItems = async () => {
    try {
      const response = await fetch('http://localhost:8080/chinease/breakfast');
      if (response.ok) {
        const data = await response.json();
        console.log('Received breakfast data:', data);
        const itemsWithImage = data.map(item => ({ ...item, selectedImage: null }));
        setBreakfastItems(itemsWithImage);
      } else {
        console.error('Failed to fetch breakfast items');
      }
    } catch (error) {
      console.error('Error fetching breakfast items:', error);
    }
  };

  const fetchCurriesItems = async () => {
    try {
      const response = await fetch('http://localhost:8080/chinease/curries');
      if (response.ok) {
        const data = await response.json();
        console.log('Received curries data:', data);
        const itemsWithImage = data.map(item => ({ ...item, selectedImage: null }));
        setCurriesItems(itemsWithImage);
      } else {
        console.error('Failed to fetch curries items');
      }
    } catch (error) {
      console.error('Error fetching curries items:', error);
    }
  };

  const fetchSoupsItems = async () => {
    try {
      const response = await fetch('http://localhost:8080/chinease/soups');
      if (response.ok) {
        const data = await response.json();
        console.log('Received soups data:', data);
        const itemsWithImage = data.map(item => ({ ...item, selectedImage: null }));
        setSoupsItems(itemsWithImage);
      } else {
        console.error('Failed to fetch soups items');
      }
    } catch (error) {
      console.error('Error fetching soups items:', error);
    }
  };
  const fetchStartersItems = async () => {
    try {
      const response = await fetch('http://localhost:8080/chinease/starters');
      if (response.ok) {
        const data = await response.json();
        console.log('Received starters data:', data);
        const itemsWithImage = data.map(item => ({ ...item, selectedImage: null }));
        setStartersItems(itemsWithImage); 
      } else {
        console.error('Failed to fetch starters items');
      }
    } catch (error) {
      console.error('Error fetching starters items:', error);
    }
  };
  const fetchMainCourseItems = async () => {
    try {
      const response = await fetch('http://localhost:8080/chinease/maincourse');
      if (response.ok) {
        const data = await response.json();
        console.log('Received main course data:', data);
        const itemsWithImage = data.map(item => ({ ...item, selectedImage: null }));
        setMainCourseItems(itemsWithImage); 
      } else {
        console.error('Failed to fetch main course items');
      }
    } catch (error) {
      console.error('Error fetching main course items:', error);
    }
  };
  const fetchDessertsItems = async () => {
    try {
      const response = await fetch('http://localhost:8080/chinease/desserts');
      if (response.ok) {
        const data = await response.json();
        console.log('Received desserts data:', data);
        const itemsWithImage = data.map(item => ({ ...item, selectedImage: null }));
        setDessertsItems(itemsWithImage);
      } else {
        console.error('Failed to fetch desserts items');
      }
    } catch (error) {
      console.error('Error fetching desserts items:', error);
    }
  };
  const fetchDrinksItems = async () => {
    try {
      const response = await fetch('http://localhost:8080/chinease/drinks');
      if (response.ok) {
        const data = await response.json();
        console.log('Received drinks data:', data);
        const itemsWithImage = data.map(item => ({ ...item, selectedImage: null }));
        setDrinksItems(itemsWithImage); 
      } else {
        console.error('Failed to fetch drinks items');
      }
    } catch (error) {
      console.error('Error fetching drinks items:', error);
    }
  };
  

  const handleFileChange = (event, index, itemType) => {
    const file = event.target.files[0];
    const setterFunction = itemType === 'breakfast' ? setBreakfastItems : setCurriesItems;

    setterFunction(prevItems => {
      const updatedItems = [...prevItems];
      updatedItems[index].selectedImage = URL.createObjectURL(file);
      return updatedItems;
    });
  };

  const handleCurriesFileChange = (event, index) => {
    const file = event.target.files[0];
    
    setCurriesItems(prevItems => {
      const updatedItems = [...prevItems];
      updatedItems[index].selectedImage = URL.createObjectURL(file);
      return updatedItems;
    });
  };

  return (
    <>
      <div className="chinease-menu-container">
      <Link to={'/Restaurant'}>
      <button type='submit'>Back</button>
      </Link>
        <h3>Chinease Breakfast</h3>
        <table>
          <thead>
            <tr>
              <th>Breakfast</th>
              <th>Price</th>
              <th>Image</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {breakfastItems.map((item, index) => (
              <tr key={index}>
                <td>{item.breakfast}</td>
                <td>{item.b_price}</td>
                <td>
                  {item.selectedImage ? (
                    <img src={item.selectedImage} alt="Selected" style={{ maxWidth: '100px', maxHeight: '100px' }} />
                  ) : (
                    <input type='file' onChange={(event) => handleFileChange(event, index, 'breakfast')} />
                  )}
                </td>
                <td>
                  <Link to={'/UpdateChineaseBreakfast'}>
                    <button className="s" onClick={() => decrementQuantity('Croissant')}>
                      Update
                    </button>
                  </Link>
                  <Link to={'/DeleteChineaseBreakfast'}>
                    <button className="s" onClick={() => removeFromCart('Croissant')}>
                      Delete
                    </button>
                  </Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
     
      <div>
        <Link to={'/AddChineaseBreakfast'}>
          <button className="s" onClick={() => addToCart()}>
            Add
          </button>
        </Link>
      </div>
      <h3> Chinease Curries</h3>
<table>
  <thead>
    <tr>
      <th>Curry</th>
      <th>Price</th>
      <th>Image</th>
      <th>Actions</th>
    </tr>
  </thead>
  <tbody>
    {curriesItems.map((item, index) => (
      <tr key={index}>
        <td>{item.curries}</td>
        <td>{item.c_price}</td>
        <td>
          {item.selectedImage ? (
            <img src={item.selectedImage} alt="Selected" style={{ maxWidth: '100px', maxHeight: '100px' }} />
          ) : (
            <input type='file' onChange={(event) => handleFileChange(event, index, 'curries')} />
          )}
        </td>
        <td>
          <Link to={'/UpdateChineaseCurries'}>
            <button className="s" onClick={() => decrementQuantity(item.curries)}>
              Update
            </button>
          </Link>
          <Link to={'/DeleteChineaseCurries'}>
            <button className="s" onClick={() => removeFromCart(item.curries)}>
              Delete
            </button>
          </Link>
        </td>
      </tr>
    ))}
  </tbody>
</table>

<div>
        <Link to={'/AddChineaseBreakfast'}>
          <button className="s" onClick={() => addToCart()}>
            Add
          </button>
        </Link>
      </div>
      <h3> Chinease Soups</h3>
<table>
  <thead>
    <tr>
      <th>Soups</th>
      <th>Price</th>
      <th>Image</th>
      <th>Actions</th>
    </tr>
  </thead>
  <tbody>
    {soupsItems.map((item, index) => (
      <tr key={index}>
        <td>{item.soups}</td>
        <td>{item.s_price}</td>
        <td>
          {item.selectedImage ? (
            <img src={item.selectedImage} alt="Selected" style={{ maxWidth: '100px', maxHeight: '100px' }} />
          ) : (
            <input type='file' onChange={(event) => handleFileChange(event, index, 'soups')} />
          )}
        </td>
        <td>
          <Link to={'/UpdateChineaseSoups'}>
            <button className="s" onClick={() => decrementQuantity(item.soups)}>
              Update
            </button>
          </Link>
          <Link to={'/DeleteChineaseSoups'}>
            <button className="s" onClick={() => removeFromCart(item.soups)}>
              Delete
            </button>
          </Link>
        </td>
      </tr>
    ))}
  </tbody>
</table>

<div>
        <Link to={'/AddChineaseSoups'}>
          <button className="s" onClick={() => addToCart()}>
            Add
          </button>
        </Link>
      </div>
      <div>
  <h3>Chinease Starters</h3>
  <table>
    <thead>
      <tr>
        <th>Starter</th>
        <th>Price</th>
        <th>Image</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      {startersItems.map((item, index) => (
        <tr key={index}>
          <td>{item.starters}</td>
          <td>{item.s1_price}</td>
          <td>
            {item.selectedImage ? (
              <img src={item.selectedImage} alt="Selected" style={{ maxWidth: '100px', maxHeight: '100px' }} />
            ) : (
              <input type='file' onChange={(event) => handleFileChange(event, index, 'starters')} />
            )}
          </td>
          <td>
            <Link to={'/UpdateChineaseStarters'}>
              <button className="s" onClick={() => decrementQuantity(item.starters)}>
                Update
              </button>
            </Link>
            <Link to={'/DeleteChineaseStarters'}>
              <button className="s" onClick={() => removeFromCart(item.starters)}>
                Delete
              </button>
            </Link>
          </td>
        </tr>
      ))}
    </tbody>
  </table>
</div>
<div>
  <Link to={'/AddChineaseStarters'}>
    <button className="s" onClick={() => addToCart()}>
      Add
    </button>
  </Link>
</div>
<div>
  <h3>Chinease Main Courses</h3>
  <table>
    <thead>
      <tr>
        <th>Main Course</th>
        <th>Price</th>
        <th>Image</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      {mainCourseItems.map((item, index) => (
        <tr key={index}>
          <td>{item.maincourse}</td>
          <td>{item.m_price}</td>
          <td>
            {item.selectedImage ? (
              <img src={item.selectedImage} alt="Selected" style={{ maxWidth: '100px', maxHeight: '100px' }} />
            ) : (
              <input type='file' onChange={(event) => handleFileChange(event, index, 'maincourse')} />
            )}
          </td>
          <td>
            <Link to={'/UpdateChineaseMainCourse'}>
              <button className="s" onClick={() => decrementQuantity(item.maincourse)}>
                Update
              </button>
            </Link>
            <Link to={'/DeleteChineaseMainCourse'}>
              <button className="s" onClick={() => removeFromCart(item.maincourse)}>
                Delete
              </button>
            </Link>
          </td>
        </tr>
      ))}
    </tbody>
  </table>
</div>
<div>
  <Link to={'/AddChineaseMainCourse'}>
    <button className="s" onClick={() => addToCart()}>
      Add
    </button>
  </Link>
</div>
<div>
  <h3>Chinease Desserts</h3>
  <table>
    <thead>
      <tr>
        <th>Dessert</th>
        <th>Price</th>
        <th>Image</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      {dessertsItems.map((item, index) => (
        <tr key={index}>
          <td>{item.desserts}</td>
          <td>{item.d_price}</td>
          <td>
            {item.selectedImage ? (
              <img src={item.selectedImage} alt="Selected" style={{ maxWidth: '100px', maxHeight: '100px' }} />
            ) : (
              <input type='file' onChange={(event) => handleFileChange(event, index, 'desserts')} />
            )}
          </td>
          <td>
            <Link to={'/UpdateChineaseDesserts'}>
              <button className="s" onClick={() => decrementQuantity(item.desserts)}>
                Update
              </button>
            </Link>
            <Link to={'/DeleteChineaseDesserts'}>
              <button className="s" onClick={() => removeFromCart(item.desserts)}>
                Delete
              </button>
            </Link>
          </td>
        </tr>
      ))}
    </tbody>
  </table>
</div>
<div>
  <Link to={'/AddChineaseDesserts'}>
    <button className="s" onClick={() => addToCart()}>
      Add
    </button>
  </Link>
</div>
<div>
  <h3>Chinease Drinks</h3>
  <table>
    <thead>
      <tr>
        <th>Drink</th>
        <th>Price</th>
        <th>Image</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      {drinksItems.map((item, index) => (
        <tr key={index}>
          <td>{item.drinks}</td>
          <td>{item.d1_price}</td>
          <td>
            {item.selectedImage ? (
              <img src={item.selectedImage} alt="Selected" style={{ maxWidth: '100px', maxHeight: '100px' }} />
            ) : (
              <input type='file' onChange={(event) => handleFileChange(event, index, 'drinks')} />
            )}
          </td>
          <td>
            <Link to={'/UpdateChineaseDrinks'}>
              <button className="s" onClick={() => decrementQuantity(item.drinks)}>
                Update
              </button>
            </Link>
            <Link to={'/DeleteChineaseDrinks'}>
              <button className="s" onClick={() => removeFromCart(item.drinks)}>
                Delete
              </button>
            </Link>
          </td>
        </tr>
      ))}
    </tbody>
  </table>
</div>
<div>
  <Link to={'/AddChineaseDrinks'}>
    <button className="s" onClick={() => addToCart()}>
      Add
    </button>
  </Link>
</div>
      </div>

      
    </>
  );
};

export default ChineaseMenu;
