import {useState, useEffect} from "react";
import { Link } from "react-router-dom";
import axios from "axios";
import './Admindashboard.css';
import './Repostat.css'

function Repostat() {
    const [customers, setCustomers] = useState([]);

    useEffect(() => {
    
        axios.get('http://localhost:8073/customers/getAll')
          .then(response => {
            // Set the data in the state
            setCustomers(response.data);
          })
          .catch(error => {
            console.error('Error fetching data:', error);
          });
      }, []);
    return (
        <>
           <div className="containerad">
          <div className="sidebar">
        <ul>
        <Link to={"/Allorders"} style={{textDecoration:"none"}}>
          <li><a href="#" style={{marginLeft:"-0.2cm"}}>Orders</a></li>
          </Link>
          <Link to={'/Repostat'}>
          <li><a href="#" style={{marginLeft:"-0.3cm"}}>Reports</a></li>
          </Link>
          <li><a href="#" style={{marginLeft:"-0.7cm"}}>MenuItems</a></li>
          <Link to={'/LoginCard'}>
          <li><a href='/LoginCard' style={{marginLeft:"-0.4cm"}}>Signout</a></li>
          </Link>
        </ul>
      </div>
        
                </div>
                    <h3 className="customer" style={{marginTop:"2cm"}}>Date&time :</h3>
                
                <h3 className="customers" style={{marginTop:"2cm"}}>Customer ID :</h3>
                <div className='container'>
                        <h1 className='text-center' style={{marginTop:"2cm",marginLeft:"4cm"}}>Status</h1><br/>
                        <div className="table-responsive">
                        <table className='table table-striped table-sm' style={{marginLeft:"2cm"}}>
                            <thead>
                            <tr>
                                <th>date</th>
                                <th>booked</th>
                                <th>available</th>
                                <th>check_out</th>
                            </tr>
                            </thead>
                            <tbody>
                            {customers.map((customer) => (
                                <tr key={customer.date}>
                                <td>{customer.date}</td>
                                <td>{customer.booked}</td>
                                <td>{customer.available}</td>
                                <td>{customer.check_out}</td>
                                </tr>
                            ))}
                            </tbody>
                        </table>
                        <Link to={'/Orders'}>
                        <button type='submit' style={{marginTop:"11cm",marginLeft:"2cm"}}>Back</button>
                        </Link>
                        </div>
                       
                    </div>

           
                

              
           
            
        </>
    );
}


export default Repostat;
