import React from 'react';
import './Orders.css';
import { Link } from "react-router-dom";


const Orders = () => {
  return (
    <div className="containerad">
      
      <div className="search-container">
        <input type='search' placeholder='Search...' className='search-input' />
      </div>
      <div className="sidebar">
        <ul>
        <Link to={"/Allorders"} style={{textDecoration:"none"}}>
          <li><a href="#" style={{marginLeft:"-0.2cm"}}>Orders</a></li>
          </Link>
          <Link to={'/Repostat'}>
          <li><a href="#" style={{marginLeft:"-0.3cm"}}>Reports</a></li>
          </Link>
          <Link to={'/Restaurantmenu'}>
          <li><a href="#" style={{marginLeft:"-0.7cm"}}>MenuItems</a></li>
          </Link>
          <Link to={'/LoginCard'}>
          <li><a href='/LoginCard' style={{marginLeft:"-0.4cm"}}>Signout</a></li>
          </Link>
        </ul>
      </div>
      <Link to={'/Roomservice'} style={{textDecoration:"none"}}>
      <div className='cardad1'>
        <h6 className='room'>Roomservice</h6>
        <div>
      <img src="https://revenue-hub.com/wp-content/uploads/2021/09/hotel-room-service-source-of-revenue.jpg" alt="roomservice" className='roomimg'/>
      </div>
      </div>
    
      </Link>
      <Link to={'/Takeaway'} style={{textDecoration:"none"}}>
      <div className='cardad2'>
        <h6 className='room'>Takeaway</h6>
        <div>
      <img src="https://bonzabfs.com.au/wp-content/uploads/2020/12/shutterstock_585472955_8563-5fcef51c19f7c.jpg" alt="takeaway" className='takeimg'/>
      </div>
      </div>
      </Link>
      <Link to={'/Dineinn'} style={{textDecoration:"none"}}>
      <div className='cardad3'>
        <h6 className='room'>Dineinn</h6>
        <div>
      <img src="https://i.pinimg.com/originals/98/d6/47/98d6476cdf0def20589997a73df2a7bf.jpg" alt="Dineinn" className='dineimg'/>
      </div>
      </div>
      </Link>
</div>

  )};

export default Orders;





